@extends('layout')

@section('content')
<h1>the About page comes here</h1>	
@stop