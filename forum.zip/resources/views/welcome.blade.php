@extends('layout')

@section('content')
<h1>Forum</h1>
<a href="/cards">Threads</a>

@stop