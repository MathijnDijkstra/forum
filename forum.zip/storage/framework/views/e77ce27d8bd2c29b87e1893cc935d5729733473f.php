<?php $__env->startSection('content'); ?>
<h1>Forum</h1>
<a href="/cards">Threads</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>